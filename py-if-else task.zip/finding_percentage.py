def find_percentage(marks):
    total = sum(marks)
    avg = total / len(marks)
    return avg

if __name__ == "__main__":
    n = int(input("Enter number of subjects: "))
    student_marks = list(map(float, input("Enter marks: ").split()))
    print(f"Percentage: {find_percentage(student_marks):.2f}")
