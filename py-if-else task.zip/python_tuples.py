def tuple_example():
    t = (1, 2, 3)
    print(f"Tuple: {t}")
    print(f"Hash of tuple: {hash(t)}")

if __name__ == "__main__":
    tuple_example()

