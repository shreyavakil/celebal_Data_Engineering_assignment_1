from itertools import combinations

def calculate_probability(n, k, arr):
    total_combinations = list(combinations(arr, k))
    favorable = [comb for comb in total_combinations if sum(comb) % 2 == 0]  # Example condition
    return len(favorable) / len(total_combinations) if total_combinations else 0

if __name__ == "__main__":
    n, k = map(int, input("Enter n and k: ").split())
    arr = list(map(int, input(f"Enter {n} numbers: ").split()))
    prob = calculate_probability(n, k, arr)
    print(f"Probability: {prob:.3f}")

