from itertools import groupby

def compress_string(s):
    compressed = ""
    for char, group in groupby(s):
        count = len(list(group))
        compressed += char + str(count)
    return compressed

if __name__ == "__main__":
    string = input("Enter a string to compress: ")
    print(compress_string(string))
