from collections import OrderedDict

def word_order(words):
    count_dict = OrderedDict()
    for word in words:
        count_dict[word] = count_dict.get(word, 0) + 1
    return count_dict

if __name__ == "__main__":
    n = int(input("Enter number of words: "))
    words_list = [input() for _ in range(n)]
    counts = word_order(words_list)
    print(len(counts))
    for word, count in counts.items():
        print(count, end=' ')

