def format_string(name, score):
    print(f"{name:<10} | Score: {score:>5.2f}")

if __name__ == "__main__":
    name = input("Enter name: ")
    score = float(input("Enter score: "))
    format_string(name, score)

