def check_number(num):
    if num > 0:
        return "Positive"
    elif num == 0:
        return "Zero"
    else:
        return "Negative"

if __name__ == "__main__":
    n = int(input("Enter a number: "))
    print(check_number(n))
